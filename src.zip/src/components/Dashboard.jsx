import React, { useState, useMemo } from 'react';
import PropTypes from 'prop-types';
import NewNoteModal from './Modals/NewNoteModal';
import EditNoteModal from './Modals/EditNoteModal';
import SettingsModal from './Modals/SettingsModal';

const Dashboard = ({ notes, refreshNotes, addSiteNote, projects, jobs }) => {
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [activeSubModal, setActiveSubModal] = useState(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedNote, setSelectedNote] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchColumn, setSearchColumn] = useState('');
  const [hierarchy, setHierarchy] = useState([]);
  const [selectedValues, setSelectedValues] = useState({});

  const handleDragStart = (column) => {
    return (e) => {
      e.dataTransfer.setData('column', column);
    };
  };
  const handleOpenSubModal = (modalId) => {
    console.log(`Opening sub-modal: ${modalId}`);
    setActiveSubModal(modalId);
   
  };
  const handleCloseSettingsModal = () => {
    setShowSettingsModal(false);
    setActiveSubModal(null); 
  };
  const handleCloseNewModal = () => {
    setShowNewModal(false);
    refreshNotes();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const column = e.dataTransfer.getData('column');
    if (column && !['attachmentFileName', 'actions'].includes(column)) {
      if (!hierarchy.includes(column)) {
        setHierarchy([...hierarchy, column]);
        setSelectedValues({...selectedValues, [column]: ''});
      }
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleHierarchyChange = (column, value) => {
    const newSelectedValues = {...selectedValues, [column]: value};
    setSelectedValues(newSelectedValues);
    
    
    const columnIndex = hierarchy.indexOf(column);
    if (columnIndex < hierarchy.length - 1) {
      hierarchy.slice(columnIndex + 1).forEach(col => {
        newSelectedValues[col] = '';
      });
    }
  };

  const removeHierarchyLevel = (column) => {
    const index = hierarchy.indexOf(column);
    setHierarchy(hierarchy.filter(col => col !== column));
    
    const newSelectedValues = {...selectedValues};
    delete newSelectedValues[column];
    setSelectedValues(newSelectedValues);
  };

  const filteredNotes = useMemo(() => {
    let result = [...notes];
    
    
    hierarchy.forEach(column => {
      const selectedValue = selectedValues[column];
      if (selectedValue) {
        result = result.filter(note => {
          const noteValue = column === 'date' 
            ? new Date(note[column]).toLocaleDateString() 
            : note[column];
          return noteValue === selectedValue;
        });
      }
    });
    
    
    if (searchTerm && searchColumn) {
      result = result.filter(note => 
        String(note[searchColumn]).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    return result;
  }, [notes, hierarchy, selectedValues, searchTerm, searchColumn]);

  const getUniqueValues = (column, currentNotes) => {
    const values = new Set();
    currentNotes.forEach(note => {
      const value = column === 'date' 
        ? new Date(note[column]).toLocaleDateString() 
        : note[column];
      if (value) values.add(value);
    });
    return Array.from(values).sort();
  };

  const getCurrentNotesForLevel = (level) => {
    let currentNotes = [...notes];
    
    
    for (let i = 0; i < level; i++) {
      const column = hierarchy[i];
      const selectedValue = selectedValues[column];
      if (selectedValue) {
        currentNotes = currentNotes.filter(note => {
          const noteValue = column === 'date' 
            ? new Date(note[column]).toLocaleDateString() 
            : note[column];
          return noteValue === selectedValue;
        });
      }
    }
    
    return currentNotes;
  };

  const handleEdit = (note) => {
    setSelectedNote(note);
    setShowEditModal(true);
  };

  const handleDelete = async (noteId) => {
    if (window.confirm('Are you sure you want to delete this note?')) {
      try {
        await fetch(`/api/notes/${noteId}`, { method: 'DELETE' });
        refreshNotes();
      } catch (error) {
        console.error('Error deleting note:', error);
      }
    }
  };

  return (
    <div className="main-content">
      <div className="dashboard">
        <h1><i className="fas fa-clipboard-list"></i> Site Notes Dashboard</h1>

        <button 
          className="settings-btn" 
          onClick={() => setShowSettingsModal(true)}
        >
          <i className="fas fa-sliders-h"></i> Settings
        </button>

        {showSettingsModal && (
        <SettingsModal
          isOpen={showSettingsModal}
          onClose={handleCloseSettingsModal}
          openSubModal={handleOpenSubModal}
        />
      )}

        <div 
          className="search-box"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          <input 
            id="searchInput"
            type="text" 
            placeholder={searchColumn ? `Search by ${searchColumn}...` : "Search notes..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchColumn && (
            <span className="search-hint">
              Search by: {searchColumn}
              <button 
                onClick={() => {
                  setSearchColumn('');
                  setSearchTerm('');
                }}
                className="clear-group-btn"
              >
                ×
              </button>
            </span>
          )}
          <button id="searchBtn"><i className="fas fa-search"></i> Search</button>
          <button id="newBtn" className="btn-primary" onClick={() => setShowNewModal(true)}>
            <i className="fas fa-plus-circle"></i> New Note
          </button>
          {showNewModal && (
        <NewNoteModal
          isOpen={showNewModal}
          onClose={handleCloseNewModal}
          addSiteNote={addSiteNote}  
          refreshNotes={refreshNotes}
          projects={projects}       
          jobs={jobs}
          />
      )}
        </div>

        {/* Hierarchy filters */}
        <div className="hierarchy-filters">
          {hierarchy.map((column, level) => {
            const currentNotes = getCurrentNotesForLevel(level);
            const uniqueValues = getUniqueValues(column, currentNotes);
            
            return (
              <div key={column} className="hierarchy-level">
                <label>
                  {column.charAt(0).toUpperCase() + column.slice(1)}:
                  <select
                    value={selectedValues[column] || ''}
                    onChange={(e) => handleHierarchyChange(column, e.target.value)}
                  >
                    <option value="">All {column}s</option>
                    {uniqueValues.map(value => (
                      <option key={value} value={value}>
                        {value}
                      </option>
                    ))}
                  </select>
                </label>
                <button 
                  onClick={() => removeHierarchyLevel(column)}
                  className="clear-hierarchy-btn"
                >
                  ×
                </button>
              </div>
            );
          })}
          {hierarchy.length > 0 && (
            <button 
              onClick={() => {
                setHierarchy([]);
                setSelectedValues({});
              }}
              className="clear-all-hierarchy-btn"
            >
              Clear all filters
            </button>
          )}
        </div>

        <table>
          <thead>
            <tr>
              {['date', 'project', 'job', 'note', 'userName', 'Attached File'].map(col => (
                <th 
                  key={col} 
                  draggable 
                  onDragStart={handleDragStart(col)}
                  className={hierarchy.includes(col) ? 'hierarchy-column' : ''}
                >
                  {col === 'date' && <i className="far fa-calendar-alt"></i>}
                  {col === 'project' && <i className="fas fa-project-diagram"></i>}
                  {col === 'job' && <i className="fas fa-tasks"></i>}
                  {col === 'note' && <i className="far fa-sticky-note"></i>}
                  {col === 'userName' && <i className="fas fa-user"></i>}
                  {col === 'Attached File' && <i className="fas fa-paperclip"></i>}
                  {' '}
                  {col.charAt(0).toUpperCase() + col.slice(1)}
                </th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredNotes.map(note => (
              <tr key={note.id}>
                <td>
                  {new Date(note.date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                  })}
                </td>
                <td>{note.project}</td>
                <td>{note.job}</td>
                <td 
                  className="editable" 
                  onDoubleClick={() => handleEdit(note)} 
                  title={note.note}
                >
                  {note.note.length > 50 ? `${note.note.substring(0, 50)}...` : note.note}
                </td>
                <td>{note.userName}</td>
                <td className="file-cell">
                  {note.attachmentFileName ? (
                    <>
                      <i className="fas fa-file-pdf file-icon"></i>
                      <span className="file-name">{note.attachmentFileName}</span>
                    </>
                  ) : (
                    <i className="fas fa-plus file-icon"></i>
                  )}
                </td>
                <td className="table-actions">
                  <a title="Edit" onClick={() => handleEdit(note)}>
                    <i className="fas fa-edit"></i>
                  </a>
                  <a title="Delete" onClick={() => handleDelete(note.id)}>
                    <i className="fas fa-trash"></i>
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showNewModal && <NewNoteModal onClose={() => setShowNewModal(false)} refreshNotes={refreshNotes} />}
      {showEditModal && <EditNoteModal note={selectedNote} onClose={() => setShowEditModal(false)} refreshNotes={refreshNotes} />}
      {showSettingsModal && <SettingsModal onClose={() => setShowSettingsModal(false)} />}
    </div>
  );
};

Dashboard.propTypes = {
  notes: PropTypes.array.isRequired,
  refreshNotes: PropTypes.func.isRequired,
  addSiteNote: PropTypes.func.isRequired,
  projects: PropTypes.array,
  jobs: PropTypes.array
};

Dashboard.defaultProps = {
  projects: [],
  jobs: []
};

export default Dashboard;