import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Modal from './Modal';
import './SettingsModal.css';

const SettingsModal = ({ isOpen, onClose }) => {
  
  const [activeTab, setActiveTab] = useState(null); 
  const [projects, setProjects] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [users, setUsers] = useState([]);
  const [databases, setDatabases] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedJob, setSelectedJob] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedDatabase, setSelectedDatabase] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('Active');
  const [newProjectName, setNewProjectName] = useState('');
  const [newJobName, setNewJobName] = useState('');
  
  
  const [isAddProjectOpen, setIsAddProjectOpen] = useState(false);
  const [isEditProjectOpen, setIsEditProjectOpen] = useState(false);
  const [isAddJobOpen, setIsAddJobOpen] = useState(false);
  const [isEditJobOpen, setIsEditJobOpen] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchInitialData();
    }
  }, [isOpen]);
  const fetchInitialData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const projectsUrl = 'https://localhost:7204/api/Sitebook/GetProject';
      const jobsUrl = 'https://localhost:7204/api/Sitebook/Getjob';
      
      console.log('Fetching from:', projectsUrl, jobsUrl);

      const [projectsRes, jobsRes] = await Promise.all([
        fetch(projectsUrl, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        }),
        fetch(jobsUrl, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        })
      ]);

      if (!projectsRes.ok) throw new Error(`Projects API error: ${projectsRes.status}`);
      if (!jobsRes.ok) throw new Error(`Jobs API error: ${jobsRes.status}`);

      const projectsData = await projectsRes.json();
      const jobsData = await jobsRes.json();

      console.log('Received data:', { projectsData, jobsData });

      setProjects(projectsData);
      setJobs(jobsData);
    } catch (err) {
      setError(err.message);
      console.error('API Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProject = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/AddProject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newProjectName })
      });

      if (!response.ok) throw new Error('Failed to add project');
      
      fetchInitialData(); // Refresh data
      setNewProjectName('');
      setIsAddProjectOpen(false);
    } catch (err) {
      setError(err.message);
      console.error('Error adding project:', err);
    }
  };

  const handleEditProject = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/UpdateProject`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          id: selectedProject,
          name: newProjectName 
        })
      });

      if (!response.ok) throw new Error('Failed to update project');
      
      fetchInitialData(); // Refresh data
      setNewProjectName('');
      setIsEditProjectOpen(false);
    } catch (err) {
      setError(err.message);
      console.error('Error updating project:', err);
    }
  };

  const handleDeleteProject = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/DeleteProject/${selectedProject}`, {
        method: 'DELETE'
      });

      if (!response.ok) throw new Error('Failed to delete project');
      
      fetchInitialData(); // Refresh data
      setSelectedProject('');
    } catch (err) {
      setError(err.message);
      console.error('Error deleting project:', err);
    }
  };

  const handleAddJob = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/AddJob`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          name: newJobName,
          projectId: selectedProject
        })
      });

      if (!response.ok) throw new Error('Failed to add job');
      
      fetchInitialData(); // Refresh data
      setNewJobName('');
      setIsAddJobOpen(false);
    } catch (err) {
      setError(err.message);
      console.error('Error adding job:', err);
    }
  };

  const handleEditJob = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/UpdateJob`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          id: selectedJob,
          name: newJobName,
          projectId: selectedProject
        })
      });

      if (!response.ok) throw new Error('Failed to update job');
      
      fetchInitialData(); // Refresh data
      setNewJobName('');
      setIsEditJobOpen(false);
    } catch (err) {
      setError(err.message);
      console.error('Error updating job:', err);
    }
  };

  const handleDeleteJob = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/DeleteJob/${selectedJob}`, {
        method: 'DELETE'
      });

      if (!response.ok) throw new Error('Failed to delete job');
      
      fetchInitialData(); // Refresh data
      setSelectedJob('');
    } catch (err) {
      setError(err.message);
      console.error('Error deleting job:', err);
    }
  };

  const handleAddUser = () => {
    alert(`User ${selectedUser} added to database ${selectedDatabase}`);
    setSelectedUser('');
    setSelectedDatabase('');
  };

  const handleRemoveUser = () => {
    alert(`User ${selectedUser} removed from database ${selectedDatabase}`);
    setSelectedUser('');
    setSelectedDatabase('');
  };

  const handleGrantPermission = () => {
    alert(`Permission granted to user ${selectedUser} for job ${selectedJob}`);
    setSelectedUser('');
    setSelectedProject('');
    setSelectedJob('');
  };

  const handleDenyPermission = () => {
    alert(`Permission denied to user ${selectedUser} for job ${selectedJob}`);
    setSelectedUser('');
    setSelectedProject('');
    setSelectedJob('');
  };

  const handleUpdateStatus = () => {
    alert(`Job ${selectedJob} status updated to ${selectedStatus}`);
    setSelectedProject('');
    setSelectedJob('');
    setSelectedStatus('Active');
  };

  
  const renderProjectManagement = () => (
    <div className="settings-content">
      <div className="settings-action-buttons">
        <button className="btn-primary" onClick={() => setIsAddProjectOpen(true)}>
          Add Project
        </button>
        <button className="btn-secondary" onClick={() => setIsEditProjectOpen(true)} disabled={!selectedProject}>
          Edit Project
        </button>
        <button className="btn-danger" onClick={handleDeleteProject} disabled={!selectedProject}>
          Delete Project
        </button>
      </div>
      
      <div className="settings-lookup-list">
        <h4>Project Lookups</h4>
        <select 
          size="5" 
          className="lookup-select"
          value={selectedProject}
          onChange={(e) => setSelectedProject(e.target.value)}
        >
          {projects.map(project => (
            <option key={project.id} value={project.id}>
              {project.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );

  const renderJobManagement = () => (
    <div className="settings-content">
      <div className="settings-action-buttons">
        <button className="btn-primary" onClick={() => setIsAddJobOpen(true)}>
          Add Job
        </button>
        <button className="btn-secondary" onClick={() => setIsEditJobOpen(true)} disabled={!selectedJob}>
          Edit Job
        </button>
        <button className="btn-danger" onClick={handleDeleteJob} disabled={!selectedJob}>
          Delete Job
        </button>
      </div>
      
      <div className="settings-lookup-list">
        <h4>Job Lookups</h4>
        <select 
          size="5" 
          className="lookup-select"
          value={selectedJob}
          onChange={(e) => setSelectedJob(e.target.value)}
        >
          {jobs.map(job => (
            <option key={job.id} value={job.id}>
              {job.name} (Project: {projects.find(p => p.id === job.projectId)?.name || 'Unknown'})
            </option>
          ))}
        </select>
      </div>
    </div>
  );

  const renderUserManagement = () => (
    <div className="settings-content">
      <div className="settings-form">
        <div className="form-group">
          <label>Username:</label>
          <select 
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
          >
            <option value="">Select User</option>
            {users.map(user => (
              <option key={user.id} value={user.id}>{user.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Database:</label>
          <select 
            value={selectedDatabase}
            onChange={(e) => setSelectedDatabase(e.target.value)}
          >
            <option value="">Select Database</option>
            {databases.map(db => (
              <option key={db.id} value={db.id}>{db.name}</option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="settings-action-buttons">
        <button className="btn-primary" onClick={handleAddUser} disabled={!selectedUser || !selectedDatabase}>
          Add User
        </button>
        <button className="btn-danger" onClick={handleRemoveUser} disabled={!selectedUser || !selectedDatabase}>
          Remove User
        </button>
      </div>
    </div>
  );

  const renderJobPermissions = () => (
    <div className="settings-content">
      <div className="settings-form">
        <div className="form-group">
          <label>Username:</label>
          <select 
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
          >
            <option value="">Select User</option>
            {users.map(user => (
              <option key={user.id} value={user.id}>{user.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Project:</label>
          <select 
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
          >
            <option value="">Select Project</option>
            {projects.map(project => (
              <option key={project.id} value={project.id}>{project.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Job:</label>
          <select 
            value={selectedJob}
            onChange={(e) => setSelectedJob(e.target.value)}
            disabled={!selectedProject}
          >
            <option value="">Select Job</option>
            {jobs.filter(job => job.projectId === parseInt(selectedProject)).map(job => (
              <option key={job.id} value={job.id}>{job.name}</option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="settings-action-buttons">
        <button className="btn-primary" onClick={handleGrantPermission} disabled={!selectedUser || !selectedProject || !selectedJob}>
          Grant
        </button>
        <button className="btn-danger" onClick={handleDenyPermission} disabled={!selectedUser || !selectedProject || !selectedJob}>
          Deny
        </button>
      </div>
    </div>
  );

  const renderJobStatusUpdate = () => (
    <div className="settings-content">
      <div className="settings-form">
        <div className="form-group">
          <label>Project:</label>
          <select 
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
          >
            <option value="">Select Project</option>
            {projects.map(project => (
              <option key={project.id} value={project.id}>{project.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Job:</label>
          <select 
            value={selectedJob}
            onChange={(e) => setSelectedJob(e.target.value)}
            disabled={!selectedProject}
          >
            <option value="">Select Job</option>
            {jobs.filter(job => job.projectId === parseInt(selectedProject)).map(job => (
              <option key={job.id} value={job.id}>{job.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Status:</label>
          <select 
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
          >
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>
      
      <div className="settings-action-buttons">
        <button className="btn-primary" onClick={handleUpdateStatus} disabled={!selectedProject || !selectedJob}>
          Update
        </button>
      </div>
    </div>
  );

  const renderMainMenu = () => (
    <div className="settings-options-container">
      {[
        { 
          id: 'projectManagement',
          icon: 'fa-project-diagram', 
          text: 'Project Management',
          description: 'Manage project configurations and details'
        },
        { 
          id: 'jobManagement',
          icon: 'fa-tasks', 
          text: 'Job Management',
          description: 'Configure and organize jobs'
        },
        { 
          id: 'userManagement',
          icon: 'fa-user-plus', 
          text: 'User Management',
          description: 'Add or remove system users'
        },
        { 
          id: 'jobPermissions',
          icon: 'fa-user-shield', 
          text: 'Job Permissions',
          description: 'Configure access control for jobs'
        },
        { 
          id: 'jobStatus',
          icon: 'fa-sync-alt', 
          text: 'Job Status Update',
          description: 'Modify job status and tracking'
        }
      ].map((option) => (
        <button
          key={option.id}
          className="settings-option"
          onClick={() => setActiveTab(option.id)}
          aria-label={`Open ${option.text} settings`}
        >
          <div className="option-icon">
            <i className={`fas ${option.icon}`} />
          </div>
          <div className="option-text">
            <h4>{option.text}</h4>
            <p>{option.description}</p>
          </div>
          <i className="fas fa-chevron-right option-arrow" />
        </button>
      ))}
    </div>
  );

  const renderContent = () => {
    if (!activeTab) return renderMainMenu();
    
    switch(activeTab) {
      case 'projectManagement':
        return renderProjectManagement();
      case 'jobManagement':
        return renderJobManagement();
      case 'userManagement':
        return renderUserManagement();
      case 'jobPermissions':
        return renderJobPermissions();
      case 'jobStatus':
        return renderJobStatusUpdate();
      default:
        return <div>Unknown settings option</div>;
    }
  };

  const getTitle = () => {
    if (!activeTab) return 'Settings';
    
    switch(activeTab) {
      case 'projectManagement':
        return 'Project Management';
      case 'jobManagement':
        return 'Job Management';
      case 'userManagement':
        return 'User Management';
      case 'jobPermissions':
        return 'Job Permissions';
      case 'jobStatus':
        return 'Job Status Update';
      default:
        return 'Settings';
    }
  };

  return (
    <>
      <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={
          <div className="settings-modal-title">
            <i className="fas fa-sliders-h settings-icon" />
            <span>{getTitle()}</span>
            {activeTab && (
              <button 
                className="back-button" 
                onClick={() => setActiveTab(null)}
              >
                <i className="fas fa-arrow-left" /> Back
              </button>
            )}
          </div>
        }
        className="settings-modal" >
           {loading ? (
          <div className="loading-message">Loading data...</div>
        ) : error ? (
          <div className="error-message">
            Error: {error}
            <button onClick={fetchInitialData}>Retry</button>
          </div>
        ) : (
          renderContent()
        )}
        
        <div className="modal-footer">
          <button className="btn-close" onClick={onClose}>
            Close
          </button>
        </div>
      </Modal>

      {/* Sub-modals */}
      <Modal 
        isOpen={isAddProjectOpen} 
        onClose={() => setIsAddProjectOpen(false)} 
        title="Add Project"
      >
        <div className="settings-form">
          <div className="form-group">
            <label>Project Name:</label>
            <input 
              type="text" 
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="Enter project name"
            />
          </div>
          
          <div className="modal-footer">
            <button className="btn-primary" onClick={handleAddProject} disabled={!newProjectName}>
              OK
            </button>
            <button className="btn-close" onClick={() => setIsAddProjectOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      <Modal 
        isOpen={isEditProjectOpen} 
        onClose={() => setIsEditProjectOpen(false)} 
        title="Edit Project"
      >
        <div className="settings-form">
          <div className="form-group">
            <label>Project Name:</label>
            <input 
              type="text" 
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="Enter project name"
            />
          </div>
          
          <div className="modal-footer">
            <button className="btn-primary" onClick={handleEditProject} disabled={!newProjectName}>
              OK
            </button>
            <button className="btn-close" onClick={() => setIsEditProjectOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      <Modal 
        isOpen={isAddJobOpen} 
        onClose={() => setIsAddJobOpen(false)} 
        title="Add Job"
      >
        <div className="settings-form">
          <div className="form-group">
            <label>Project:</label>
            <select 
              value={selectedProject}
              onChange={(e) => setSelectedProject(e.target.value)}
            >
              <option value="">Select Project</option>
              {projects.map(project => (
                <option key={project.id} value={project.id}>{project.name}</option>
              ))}
            </select>
          </div>
          
          <div className="form-group">
            <label>Job Name:</label>
            <input 
              type="text" 
              value={newJobName}
              onChange={(e) => setNewJobName(e.target.value)}
              placeholder="Enter job name"
            />
          </div>
          
          <div className="modal-footer">
            <button className="btn-primary" onClick={handleAddJob} disabled={!selectedProject || !newJobName}>
              OK
            </button>
            <button className="btn-close" onClick={() => setIsAddJobOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      <Modal 
        isOpen={isEditJobOpen} 
        onClose={() => setIsEditJobOpen(false)} 
        title="Edit Job"
      >
        <div className="settings-form">
          <div className="form-group">
            <label>Project:</label>
            <select 
              value={selectedProject}
              onChange={(e) => setSelectedProject(e.target.value)}
              disabled
            >
              {projects.map(project => (
                <option key={project.id} value={project.id}>{project.name}</option>
              ))}
            </select>
          </div>
          
          <div className="form-group">
            <label>Job Name:</label>
            <input 
              type="text" 
              value={newJobName}
              onChange={(e) => setNewJobName(e.target.value)}
              placeholder="Enter job name"
            />
          </div>
          
          <div className="modal-footer">
            <button className="btn-primary" onClick={handleEditJob} disabled={!newJobName}>
              OK
            </button>
            <button className="btn-close" onClick={() => setIsEditJobOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};

SettingsModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired
};

export default SettingsModal;