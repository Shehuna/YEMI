// src/components/Modals/EditNoteModal.jsx
import React, { useState, useEffect } from 'react';
import { updateNote } from '../../services/api';

const EditNoteModal = ({ note, onClose, refreshNotes }) => {
  const [formData, setFormData] = useState({ ...note });

  useEffect(() => {
    setFormData(note);
  }, [note]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await updateNote(note._id || note.id, formData);
      refreshNotes();
      onClose();
    } catch (err) {
      console.error('Error updating note:', err);
    }
  };

  return (
    <div className="modal">
      <h2>Edit Note</h2>
      <form onSubmit={handleSubmit}>
        <input name="date" type="date" value={formData.date?.split('T')[0]} onChange={handleChange} required />
        <input name="projectId" value={formData.projectId} onChange={handleChange} required />
        <input name="projectName" value={formData.projectName} onChange={handleChange} required />
        <input name="jobId" value={formData.jobId} onChange={handleChange} required />
        <input name="jobName" value={formData.jobName} onChange={handleChange} required />
        <textarea name="note" value={formData.note} onChange={handleChange} required />
        <input name="username" value={formData.username} onChange={handleChange} required />
        <input name="attachmentFileName" value={formData.attachmentFileName} onChange={handleChange} />
        <button type="submit">Update</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </form>
    </div>
  );
};

export default EditNoteModal;
