import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Modal from './Modal';
import './NewNoteModal.css';

const NewNoteModal = ({
  isOpen,
  onClose,
  projects = [],
  jobs = [],
  refreshNotes,
  addSiteNote
}) => {
  
  const [activeTab, setActiveTab] = useState('journal');
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedJob, setSelectedJob] = useState('');
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [documents, setDocuments] = useState([]);
  const [newDocument, setNewDocument] = useState({
    name: '',
    file: null
  });
  const [showDocumentForm, setShowDocumentForm] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [apiError, setApiError] = useState(null);
  
  useEffect(() => {
    if (selectedProject) {
      const filtered = jobs.filter(job =>
        job.projectId?.toString() === selectedProject.toString()
      );
      setFilteredJobs(filtered);
    } else {
      setFilteredJobs([]);
    }
  }, [selectedProject, jobs]);

  const handleSaveJournal = async () => {
    // Validate inputs
    const newErrors = {};
    if (!selectedProject) newErrors.project = "Please select a project";
    if (!selectedJob) newErrors.job = "Please select a job";
    if (!selectedDate) newErrors.date = "Please select a date";
    if (!noteContent.trim()) newErrors.note = "Note content is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSaving(true);
    setApiError(null);

    try {
      const noteData = {
        Note: noteContent,
        Date: new Date(selectedDate).toISOString(),
        ProjectId: selectedProject,
        JobId: selectedJob,
        UserName: "ReactAppUser" // Add this if your API expects it
      };

      console.log("Submitting note:", noteData);
      
      // Call the addSiteNote function passed from parent
      await addSiteNote(noteData);
      
      // Reset form on success
      setSelectedProject('');
      setSelectedJob('');
      setSelectedDate('');
      setNoteContent('');
      onClose();
      refreshNotes();
    } catch (error) {
      console.error("Save error:", error);
      setApiError(error.message || "Failed to save note");
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddDocument = () => {
    if (newDocument.name && newDocument.file) {
      setDocuments([...documents, newDocument]);
      setNewDocument({ name: '', file: null });
      setShowDocumentForm(false);
    }
  };

  const handleDeleteDocument = (index) => {
    const updatedDocuments = documents.filter((_, i) => i !== index);
    setDocuments(updatedDocuments);
  };

  const handleFileChange = (e) => {
    setNewDocument({ ...newDocument, file: e.target.files[0] });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="new-note-modal">
      <div className="modal-tabs">
        <button
          className={`tab-button ${activeTab === 'journal' ? 'active' : ''}`}
          onClick={() => setActiveTab('journal')} 
        >
          Journal
        </button>
        <button
          className={`tab-button ${activeTab === 'document' ? 'active' : ''}`}
          onClick={() => setActiveTab('document')}
        >
          Document
        </button>
      </div>

      

      {activeTab === 'journal' ? (
        <div className="journal-form">
          <div className="form-group">
            <label>Project</label>
            {errors.project && <span className="error-message">{errors.project}</span>}
            <div className="dropdown-with-buttons">
              <select
                value={selectedProject}
                onChange={(e) => {
                  setSelectedProject(e.target.value);
                  setSelectedJob('');
                  setErrors({...errors, project: undefined, job: undefined});
                }}
              >
                <option value="">Select Project</option>
                {projects && projects.map(project => ( 
                  <option key={project.id} value={project.id.toString()}> {}
                    {project.name} (ID: {project.id})
                  </option>
                ))}
              </select>
              <div className="action-buttons">
                <button className="find-button">Find</button>
                <button
                  className="clear-button"
                  onClick={() => {
                    setSelectedProject('');
                    setSelectedJob('');
                    setErrors({...errors, project: undefined, job: undefined});
                  }}
                >
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="form-group">
            <label>Job</label>
            {errors.job && <span className="error-message">{errors.job}</span>}
            <div className="dropdown-with-buttons">
            <select
              value={selectedJob}
              onChange={(e) => setSelectedJob(e.target.value)}
              disabled={!selectedProject}
                >
                <option value="">Select Job</option>
                {filteredJobs && filteredJobs.map(job => ( 
                  <option key={job.id} value={job.id.toString()}> {}
                    {job.name} (ID: {job.id})
                  </option>
                ))}
              </select>
              <div className="action-buttons">
                <button className="find-button">Find</button>
                <button
                  className="clear-button"
                  onClick={() => {
                    setSelectedJob('');
                    setErrors({...errors, job: undefined});
                  }}
                >
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="form-group">
            <label>Date</label>
            {errors.date && <span className="error-message">{errors.date}</span>}
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => {
                setSelectedDate(e.target.value);
                setErrors({...errors, date: undefined});
              }}
            />
          </div>

          <div className="form-group">
            <label>Note</label>
            {errors.note && <span className="error-message">{errors.note}</span>}
            <textarea
              value={noteContent}
              onChange={(e) => {
                setNoteContent(e.target.value);
                setErrors({...errors, note: undefined});
              }}
              placeholder="Write your note here..."
              rows="6"
            />
          </div>

          <div className="modal-footer">
            <button className="cancel-button" onClick={onClose}>
              Cancel
            </button>
            <button
              className="save-button"
              onClick={handleSaveJournal}
              disabled={isSaving}
            >
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      ) : (
        <div className="document-form">
          <div className="document-actions">
            <button
              className="add-button"
              onClick={() => setShowDocumentForm(true)}
            >
              Add Document
            </button>
          </div>

          {showDocumentForm && (
            <div className="document-input-form">
              <div className="form-group">
                <label>Document Name</label>
                <input
                  type="text"
                  value={newDocument.name}
                  onChange={(e) => setNewDocument({...newDocument, name: e.target.value})}
                  placeholder="Enter document name"
                />
              </div>
              <div className="form-group">
                <label>File</label>
                <input
                  type="file"
                  onChange={handleFileChange}
                />
              </div>
              <div className="form-footer">
                <button
                  className="cancel-button"
                  onClick={() => setShowDocumentForm(false)}
                >
                  Cancel
                </button>
                <button
                  className="ok-button"
                  onClick={handleAddDocument}
                  disabled={!newDocument.name || !newDocument.file}
                >
                  OK
                </button>
              </div>
            </div>
          )}

          <div className="documents-list">
            {documents.map((doc, index) => (
              <div key={index} className="document-row">
                <span className="document-name">{doc.name}</span>
                <span className="file-name">{doc.file?.name}</span>
                <button
                  className="delete-button"
                  onClick={() => handleDeleteDocument(index)}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>

          <div className="modal-footer">
            <button className="cancel-button" onClick={onClose}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
};

NewNoteModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  refreshNotes: PropTypes.func.isRequired,
  addSiteNote: PropTypes.func.isRequired,
  projects: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      name: PropTypes.string.isRequired
    })
  ),
  jobs: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      projectId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      name: PropTypes.string.isRequired
    })
  )
};

NewNoteModal.defaultProps = {
  projects: [],
  jobs: []
};

export default NewNoteModal;