import React, { useState, useEffect } from "react";
import Dashboard from "./components/Dashboard";
import "./App.css";

function App() {
  const [notes, setNotes] = useState([]);
  const [projects, setProjects] = useState([]); 
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    setError(null);
    try {
      await Promise.all([fetchNotes(), fetchProjectsAndJobs()]);
    } catch (err) {
      setError(err.message);
      console.error("Initial data loading error:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchNotes = async () => {
    try {

      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/sitebook/GetSitebook`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        }
      });
      console.log("Response status:", response); 
  
      const text = await response.text();
      console.log("Raw response:", text);
  
      if (response.ok) {
        const data = JSON.parse(text);
        setNotes(data);  
        setLoading(false);  
      } else {
        console.error(`Failed to fetch: ${response.status}`);
      }
  
    } catch (error) {
      console.error("Error fetching notes:", error);
    }
  };

 // In App.js - Update the addSiteNote function
 const addSiteNote = async (siteNoteData) => {
  try {
    const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/api/Sitebook/PostSitebook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        Note: siteNoteData.Note,
        Date: siteNoteData.Date,
        ProjectId: siteNoteData.ProjectId,
        JobId: siteNoteData.JobId,
        UserName: "ReactAppUser"
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to save note");
    }

    const responseData = await response.json();
    await fetchNotes(); // Refresh the notes list
    return responseData;
  } catch (error) {
    console.error("API Error:", error);
    throw error;
  }
};


const fetchProjectsAndJobs = async () => {
  try {
    const [projectsRes, jobsRes] = await Promise.all([
      fetch(`${process.env.REACT_APP_API_BASE_URL}/api/Sitebook/GetProject`),
      fetch(`${process.env.REACT_APP_API_BASE_URL}/api/Sitebook/Getjob`)
    ]);
    
    if (!projectsRes.ok) throw new Error(`Projects fetch failed: ${projectsRes.status}`);
    if (!jobsRes.ok) throw new Error(`Jobs fetch failed: ${jobsRes.status}`);
    
    const projectsData = await projectsRes.json();
    const jobsData = await jobsRes.json();
    
    setProjects(projectsData.map(p => ({
      id: p.id.toString(),
      name: p.name
    })));
    
    setJobs(jobsData.map(j => ({
      id: j.id.toString(),
      projectId: j.projectId.toString(),
      name: j.name
    })));
  } catch (error) {
    console.error("Error fetching projects and jobs:", error);
    throw error;
  }
};

  
return (
  <div className="app">
    {loading ? (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading data...</p>
      </div>
    ) : error ? (
      <div className="error-container">
        <p>Error: {error}</p>
        <button onClick={fetchInitialData}>Retry</button>
      </div>
    ) : (
      <Dashboard 
        notes={notes} 
        refreshNotes={fetchNotes} 
        addSiteNote={addSiteNote} 
        projects={projects}  
        jobs={jobs}
      />
    )}
  </div>
);
}

export default App;
